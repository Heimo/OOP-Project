#pragma once
#include"AI.h"
void drawGame(Player&, Player&);
void drawGame2(Player*, Player&);